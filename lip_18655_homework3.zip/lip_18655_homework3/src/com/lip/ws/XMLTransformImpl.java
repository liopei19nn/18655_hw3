/**
 *
 */
package com.lip.ws;

import javax.jws.WebService;

import com.lip.util.TransformHelper;

/**
 * @author Li Pei
 *
 * Andrew ID : lip
 */
// Service Implementation
@WebService(endpointInterface = "com.lip.ws.XMLTransform")
public class XMLTransformImpl implements XMLTransform {

    @Override
    public String[] codeTransform(String styleSheet, String inputFile, String outputFile) {
        TransformHelper th = new TransformHelper();
        th.convertXMLtoXML(styleSheet, inputFile, outputFile);
        String[] output = th.convertXMLFileToString(outputFile);
        return output;
    }


}
