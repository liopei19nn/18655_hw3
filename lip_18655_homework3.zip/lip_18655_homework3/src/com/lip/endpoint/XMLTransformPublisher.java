/**
 *
 */
package com.lip.endpoint;

import javax.xml.ws.Endpoint;

import com.lip.ws.XMLTransformImpl;

/**
 * @author Li Pei
 *
 * Andrew ID : lip
 */
// Endpoint publisher
public class XMLTransformPublisher {
    public static void main(String[] args) {
        Endpoint.publish("http://localhost:9999/ws/xmltransform", new XMLTransformImpl());
    }
}
