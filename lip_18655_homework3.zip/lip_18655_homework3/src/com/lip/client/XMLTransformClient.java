package com.lip.client;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.lip.ws.XMLTransform;

public class XMLTransformClient {

    public static void main(String[] args) throws Exception {

        URL url = new URL("http://localhost:9999/ws/xmltransform");

        // 1st argument service URI, refer to wsdl document above
        // 2nd argument is service name, refer to wsdl document above
        QName qname = new QName("http://ws.lip.com/", "XMLTransformImplService");

        Service service = Service.create(url, qname);

        XMLTransform hello = service.getPort(XMLTransform.class);
        String[] output = hello.codeTransform("style.xsl", "input.xml", "output.xml");
        for (int i = 0; i < output.length; i++) {
            System.out.println(output[i]);
        }
    }

}