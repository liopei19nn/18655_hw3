/**
 *
 */
package com.lip.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

/**
 * @author Li Pei
 *
 * Andrew ID : lip
 */
public class TransformHelper {
    public void convertXMLtoXML(String stylesheetPathname, String inputPathname, String outputPathname) {

        TransformerFactory factory = TransformerFactory.newInstance();
        Source stylesheetSource = new StreamSource(new File(stylesheetPathname).getAbsoluteFile());
        try {
            Transformer transformer = factory.newTransformer(stylesheetSource);
            Source inputSource = new StreamSource(new File(inputPathname).getAbsoluteFile());
            Result outputResult = new StreamResult(new File(outputPathname).getAbsoluteFile());
            transformer.transform(inputSource, outputResult);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String[] convertXMLFileToString(String filename) {

        BufferedReader br = null; // buffer reader

        ArrayList<String> store = new ArrayList<>();

        String currLine;

        try {

            br = new BufferedReader(new FileReader(new File(filename)));

            // read in base info

            while ((currLine = br.readLine()) != null) {
                store.add(currLine);
            }


        } catch (Exception fe) {
            fe.printStackTrace();
        }
        // return the value
        String[] ret = new String[store.size()];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = store.get(i);
        }

        return ret;
    }
}
