/**
 *
 */
package com.lip.client;

import java.util.ArrayList;

import com.lip.ws.XMLTransform;
import com.lip.ws.XMLTransformImplService;

import net.java.dev.jaxb.array.StringArray;
/**
 * @author Li Pei
 *
 * Andrew ID : lip
 */
public class XMLTransformClient {
    public static void main(String[] args) {
        System.out.println("Client Using wsimport tool");
        XMLTransformImplService helloService = new XMLTransformImplService();
        XMLTransform hello = helloService.getXMLTransformImplPort();
        StringArray a = hello.codeTransform("style.xsl", "input.xml", "output.xml");
        ArrayList<String> ret = (ArrayList<String>) a.getItem();
        for (int i = 0; i < ret.size(); i++) {
            System.out.println(ret.get(i));
        }
    }
}
