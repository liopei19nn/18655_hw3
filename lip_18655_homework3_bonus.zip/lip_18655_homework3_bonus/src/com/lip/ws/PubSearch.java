/**
 *
 */
package com.lip.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

/**
 * @author Li Pei
 *
 * Andrew ID : lip
 */
@WebService
@SOAPBinding(style = Style.RPC)
public interface PubSearch {
    @WebMethod(action = "Get_Publication_Detail")
    public String[] getPublicationDetail(@WebParam(name = "Title") String Title);


    @WebMethod(action = "List_All_CoAuthor")
    public String[] getAllCoauthor(@WebParam(name = "Author") String AuthorName);

    @WebMethod(action = "List_All_Publication")
    public String[] getAllPublication(@WebParam(name = "Author ") String AuthorName);

    @WebMethod(action = "Title_Keyword_Search")
    public String[] keywordSearch(@WebParam(name = "keyword1") String keyword1,
            @WebParam(name = "keyword2") String keyword2);

    @WebMethod(action = "Get_All_CoWork")
    public String[] getAllCowork(@WebParam(name = "author1") String author1,
            @WebParam(name = "author2") String author2);

}
