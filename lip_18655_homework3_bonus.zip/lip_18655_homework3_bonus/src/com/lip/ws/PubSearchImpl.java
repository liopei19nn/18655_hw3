/**
 *
 */
package com.lip.ws;

import java.util.ArrayList;

import javax.jws.WebService;

import com.lip.util.DatabaseIO;

/**
 * @author Li Pei
 *
 * Andrew ID : lip
 */
// Service Implementation
@WebService(endpointInterface = "com.lip.ws.PubSearch")
public class PubSearchImpl implements PubSearch {


    @Override
    public String[] getPublicationDetail(String Title) {
        DatabaseIO db = new DatabaseIO();

        String publicationDetail = db.getPublicationDetail(Title);
        String[] ret;
        if (publicationDetail.equals("This Title did not exist. Cannot find.")) {
            ret = new String[1];
            ret[0] = "This Title did not exist. Cannot find.";
        } else {
            ret = publicationDetail.split("\n");
        }
        return ret;
    }// end of method


    @Override
    public String[] getAllCoauthor(String AuthorName) {
        DatabaseIO db = new DatabaseIO();

        ArrayList<String> getAllCoauthor = db.getAllCoAuthor(AuthorName);

        if (getAllCoauthor.size() == 0) {
            getAllCoauthor.add("No Co-author");
        }

        String[] coauthor = new String[getAllCoauthor.size()];

        for (int i = 0; i < coauthor.length; i++) {
            coauthor[i] = getAllCoauthor.get(i);
        }

        return coauthor;

    }


    /*
     * (non-Javadoc)
     *
     * @see org.me.ws.PubSearch#getAllPublication(java.lang.String)
     */
    @Override
    public String[] getAllPublication(String AuthorName) {
        DatabaseIO db = new DatabaseIO();

        ArrayList<String> allPub = db.getAllPub(AuthorName);

        if (allPub.size() == 0) {
            allPub.add("Cannot Find This Author");
        }

        String[] pubs = new String[allPub.size()];

        for (int i = 0; i < pubs.length; i++) {
            pubs[i] = allPub.get(i);

        }

        return pubs;
    }

    @Override
    public String[] keywordSearch(String keyword1, String keyword2) {
        DatabaseIO db = new DatabaseIO();
        ArrayList<String> allPub = db.keyWordSearch(keyword1, keyword2);

        if (allPub.size() == 0) {
            allPub.add("No Keyword Match Title.");
        }

        String[] pubs = new String[allPub.size()];

        for (int i = 0; i < pubs.length; i++) {
            pubs[i] = allPub.get(i);
        }

        return pubs;

    }


    @Override
    public String[] getAllCowork(String author1, String author2) {
        DatabaseIO db = new DatabaseIO();
        ArrayList<String> allPub = db.getAllCoWork(author1, author2);

        if (allPub.size() == 0) {
            allPub.add("No Co-Work Found.");
        }

        String[] pubs = new String[allPub.size()];

        for (int i = 0; i < pubs.length; i++) {
            pubs[i] = allPub.get(i);
        }

        return pubs;
    }

}
