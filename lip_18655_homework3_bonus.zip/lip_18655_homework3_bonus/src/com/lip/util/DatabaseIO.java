/**
 *
 */
package com.lip.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;

import com.lip.model.Publication;

/**
 * @author Li Pei
 *
 * Andrew ID : lip
 */
public class DatabaseIO {
    private static final String URL = "jdbc:mysql://localhost:3306";
    private static final String USER_NAME = "root";
    private static final String PASSWORD = "";

    // get publication detail with this title
    public String getPublicationDetail(String title) {
        Connection connection = null;
        String ret = null;
        Publication pub = new Publication();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
            if (connection != null) {
                System.out.println("Connected to Database Successfully!");
            }

            String queryPublication = "SELECT * FROM publication.pubdetail WHERE (title=?);";

            PreparedStatement preparedStatement = connection.prepareStatement(queryPublication);
            preparedStatement.setString(1, title);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                pub.idkey = rs.getString("idkey");
                pub.mdate = rs.getString("mdate");
                String authorsString = rs.getString("author");
                String[] authors = authorsString.split(",");
                for (String s : authors) {
                    pub.author.add(s);
                }

                pub.title = rs.getString("title");
                pub.pages = rs.getString("pages");
                pub.year = rs.getString("volume");
                pub.volume = rs.getString("journal");
                pub.numbers = rs.getString("numbers");
                pub.url = rs.getString("url");
                pub.ee = rs.getString("ee");
            }

            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        ret = pub.toString();
        if (pub.author.size() == 0) {
            ret = "This Title did not exist. Cannot find.";
        }

        return ret;
    }// end of method

    // get all publication of this author
    public ArrayList<String> getAllPub(String authorName) {
        ArrayList<String> pubDetails = new ArrayList<>();
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
            if (connection != null) {
                System.out.println("Connected to Database Successfully!");
            }

            String queryPublication = "SELECT * FROM publication.author_pub WHERE (author=?);";

            PreparedStatement preparedStatement = connection.prepareStatement(queryPublication);
            preparedStatement.setString(1, authorName);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String title = rs.getString("title");
                pubDetails.add(getPublicationDetail(title));
            }

            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return pubDetails;
    }// end of method

    // keyword search the publication title
    public ArrayList<String> keyWordSearch(String keyword1, String keyword2) {

        ArrayList<String> pubTitles = new ArrayList<>();

        if (keyword1.length() == 0 && keyword2.length() == 0) {
            return pubTitles;
        }

        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
            if (connection != null) {
                System.out.println("Connected to Database Successfully!");
            }

            String queryPublication = null;
            if (keyword1.length() == 0 || keyword2.length() == 0) {
                if (keyword1.length() == 0) {
                    keyword1 = keyword2;
                } else {
                    keyword2 = keyword1;
                }
            }
            queryPublication = "select title from publication.pubdetail where " + "(title rlike '[[:<:]]" + keyword1
                    + "[[:>:]]') & " + "(title rlike '[[:<:]]" + keyword2 + "[[:>:]]');";

            PreparedStatement preparedStatement = connection.prepareStatement(queryPublication);
            // preparedStatement.setString(1, keyword1);
            // preparedStatement.setString(2, keyword1);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String title = rs.getString("title");
                pubTitles.add(title);
            }

            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return pubTitles;
    }// end of method

    // get all coauthor of this author name
    public ArrayList<String> getAllCoAuthor(String authorName) {

        ArrayList<String> ret = new ArrayList<>();
        Connection connection = null;
        HashSet<String> coauthorList = new HashSet<>();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
            if (connection != null) {
                System.out.println("Connected to Database Successfully!");
            }

            String queryPublication = "SELECT * FROM publication.author_pub WHERE (author=?);";

            PreparedStatement preparedStatement = connection.prepareStatement(queryPublication);
            preparedStatement.setString(1, authorName);
            ResultSet rs = preparedStatement.executeQuery();

            ArrayList<String> idkeyList = new ArrayList<>();
            while (rs.next()) {
                String idkey = rs.getString("idkey");
                idkeyList.add(idkey);
            }

            preparedStatement.close();

            for (String s : idkeyList) {
                String coauthorQuery = "SELECT author FROM publication.author_pub WHERE (idkey=?);";
                PreparedStatement coauthorPrepStatement = connection.prepareStatement(coauthorQuery);
                coauthorPrepStatement.setString(1, s);
                ResultSet coauthorSet = coauthorPrepStatement.executeQuery();

                while (coauthorSet.next()) {
                    String coauthor = coauthorSet.getString("author");
                    coauthorList.add(coauthor);
                }

            }
            coauthorList.remove(authorName);
            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        for (String s : coauthorList) {
            ret.add(s);
        }
        return ret;
    }// end of method

    // get all cowork of the two author
    public ArrayList<String> getAllCoWork(String authorname1, String authorname2) {
        ArrayList<String> coWorkList = new ArrayList<>();

        // if you only input one author name , return null
        if (authorname1 == null || authorname2 == null) {
            return coWorkList;
        }

        ArrayList<String> publicationList = new ArrayList<>();
        publicationList = getAllPub(authorname1);

        for (String s : publicationList) {
            String[] details = s.split("\n");
            for (String d : details) {
                if (d.startsWith("author:")) {
                    if (d.indexOf(authorname2) != -1) {
                        coWorkList.add(s);
                    }
                }
            }

        }

        return coWorkList;
    }// end of method

}
