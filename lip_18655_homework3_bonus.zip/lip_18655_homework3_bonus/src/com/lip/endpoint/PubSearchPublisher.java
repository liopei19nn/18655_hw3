/**
 *
 */
package com.lip.endpoint;

import javax.xml.ws.Endpoint;

import com.lip.ws.PubSearchImpl;

/**
 * @author Li Pei
 *
 * Andrew ID : lip
 */
// Endpoint publisher
public class PubSearchPublisher {
    public static void main(String[] args) {
        Endpoint.publish("http://localhost:9999/ws/PubSearch", new PubSearchImpl());
    }
}
