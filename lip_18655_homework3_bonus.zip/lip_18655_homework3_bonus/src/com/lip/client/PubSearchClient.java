/**
 *
 */
package com.lip.client;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.lip.ws.PubSearch;

/**
 * @author Li Pei
 *
 * Andrew ID : lip
 */
public class PubSearchClient {
    public static void main(String[] args) throws MalformedURLException {
        System.out.println("Access Publication Query Using Publised Service");
        URL url = new URL("http://localhost:9999/ws/PubSearchImpl.wsdl");

        // 1st argument service URI, refer to wsdl document above
        // 2nd argument is service name, refer to wsdl document above
        QName qname = new QName("http://ws.lip.com/", "PubSearchImplService");

        Service service = Service.create(url, qname);

        PubSearch hello = service.getPort(PubSearch.class);

        String[] output;

        System.out.println("----------------------------------------------------------------------");
        System.out.println("---------Query 1 : List All Coauthor of \"Karel Culik II\"---------");

        output = hello.getAllCoauthor("Karel Culik II");
        for (int i = 0; i < output.length; i++) {
            System.out.println(output[i]);
        }

        System.out.println("----------------------------------------------------------------------");

        System.out.println("----------------------------------------------------------------------");
        System.out.println(
                "---------Query 2 :Search \"The Derivation of Systolic Implementations of Programs.\" ---------");
        output = hello.getPublicationDetail("The Derivation of Systolic Implementations of Programs.");
        for (int i = 0; i < output.length; i++) {
            System.out.println(output[i]);
        }

        System.out.println("----------------------------------------------------------------------");

        System.out.println("---------Query 3 : List All Work of \"Karel Culik II\"---------");
        output = hello.getAllPublication("Karel Culik II");
        for (int i = 0; i < output.length; i++) {
            System.out.println(output[i]);
        }
        System.out.println("----------------------------------------------------------------------");

        System.out.println("---------Query 4 : Search Keyword \"Parallel\" and \"Assertion\"--------");

        output = hello.keywordSearch("Parallel", "Assertions");
        for (int i = 0; i < output.length; i++) {
            System.out.println(output[i]);
        }

        System.out.println("----------------------------------------------------------------------");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("---------Query 5 : Search All cowork of \"Nathan Goodman\" and \"Oded Shmueli\"--------");
        output = hello.getAllCowork("Nathan Goodman", "Oded Shmueli");
        for (int i = 0; i < output.length; i++) {
            System.out.println(output[i]);
        }

        System.out.println("----------------------------------------------------------------------");
    }

}
